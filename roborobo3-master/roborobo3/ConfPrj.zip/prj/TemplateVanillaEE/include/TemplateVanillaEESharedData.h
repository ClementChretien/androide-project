/**
 * @author Nicolas Bredeche <nicolas.bredeche@upmc.fr>
 *
 */



#ifndef TEMPLATEVANILLAEESHAREDDATA_H
#define TEMPLATEVANILLAEESHAREDDATA_H

#include "TemplateEE/include/TemplateEESharedData.h"

class TemplateVanillaEESharedData : TemplateEESharedData {
    
    // cf. super class for many parameter values.
    // Add here parameters that are specific to current implementation.
    
}; 


#endif
