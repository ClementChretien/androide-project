/*
 *  main.h
 *  roborobo
 *
 *  Created by Nicolas on 16/01/09.
 *  Copyright 2009. All rights reserved.
 *
 */

#ifndef MAIN_H
#define MAIN_H

#include "RoboroboMain/roborobo.h"


#endif // MAIN_H

