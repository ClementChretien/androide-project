/**
 * @author Nicolas Bredeche <nicolas.bredeche@upmc.fr>
 *
 */



#ifndef TEMPLATEMEDEASHAREDDATA_H
#define TEMPLATEMEDEASHAREDDATA_H

#include "TemplateEE/include/TemplateEESharedData.h"

class TemplateMedeaSharedData : TemplateEESharedData {
    
    // cf. super class for many parameter values.
    // Add here parameters that are specific to current implementation.
    
}; 


#endif
