/*
 *  WorldModel.cpp
 *  roborobo-online
 *
 *  Created by Nicolas on 20/03/09.
 *  Copyright 2009. All rights reserved.
 *
 */

#include "WorldModels/WorldModel.h"

WorldModel::WorldModel()
{
    _isAlive = true;
}

WorldModel::~WorldModel()
{
}
