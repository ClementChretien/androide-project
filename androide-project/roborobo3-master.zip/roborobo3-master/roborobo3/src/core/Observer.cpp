/*
 *  Observer.cpp
 *  roborobo-online
 *
 *  Created by Nicolas on 20/03/09.
 *  Copyright 2009. All rights reserved.
 *
 */

#include "Observers/Observer.h"

Observer::Observer( )
{
	// nothing to do.
}

Observer::~Observer()
{
	// nothing to do.
}

void Observer::stepPre()
{
	// nothing to do.
}

void Observer::stepPost()
{
    // nothing to do.
}
