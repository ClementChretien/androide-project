/*
 *  Geometry.cpp
 *  roborobo
 *
 *  Created by Nicolas on 03/12/2013.
 *
 */

#include "Utilities/Geometry.h"

// useful functions. 
// see header file for description and credits/sources.



