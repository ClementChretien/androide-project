rm -f datalog_*.txt
rm -f lite_*.txt
rm -f graph*pdf
rm -f properties_*.txt
rm -f screenshot_*
rm -f snapshot_*
rm -f trajectory_*
rm -f robotsId*
rm -f *.eps
rm -f log.txt
rm -f extract*.dat*
rm -f output.std*
rm -f fullLogger_*

